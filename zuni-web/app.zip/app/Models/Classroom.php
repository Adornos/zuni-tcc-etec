<?php

namespace App\Models;

use App\Enums\ClassroomGrade;
use App\Enums\ClassroomShift;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Classroom extends Model
{
    protected $fillable = [
        'name',
        'grade',
        'shift',
        'capacity',
        'teacher_id',
        'status',
    ];

    protected function casts(): array
    {
        return [
            'grade' => ClassroomGrade::class,
            'capacity' => 'integer',
            'shift' => ClassroomShift::class,

        ];
    }

    /**
     * Professor responsável pela turma
     */
    public function teachers(): BelongsToMany
    {
        return $this->belongsToMany(
            User::class,
            'classroom_teacher', 
            'classroom_id',
            'teacher_id',
            );
    }

    /**
     * Alunos da turma
     */
    public function students(): HasMany
    {
        return $this->hasMany(StudentSheet::class, 'classroom_id');
    }

    /**
     * Relatórios atribuídos diretamente à turma (N:N).
     * Relatórios dos alunos da turma NÃO entram aqui.
     */
    public function reports(): BelongsToMany
    {
        return $this->belongsToMany(
            Report::class,
            'report_classroom',
            'classroom_id',
            'report_id'
        );
    }

    /**
     * Relatórios da turma
     */
    public function performances(): HasMany
    {
        return $this->hasMany(ClassroomPerformance::class, 'classroom_id');
    }

    public function latestPerformance(): HasOne
    {
        return $this->hasOne(ClassroomPerformance::class)
            ->latestOfMany([
                'year',
                'period',
            ]);
    }

    public function proficiencyAverages(): HasMany
    {
        return $this->hasMany(ClassroomProficiencyAverage::class);
    }

    public function proficiencySnapshots(): HasMany
    {
        return $this->hasMany(ClassroomProficiencySnapshot::class);
    }
}

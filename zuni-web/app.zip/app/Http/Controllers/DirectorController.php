<?php

namespace App\Http\Controllers;

use App\Enums\UserRole;

use App\Models\Enrollment;
use App\Models\Report;
use App\Models\Schedule;
use App\Models\User;
use App\Models\DirectorSheet;

use Illuminate\Http\Request;

use Illuminate\Http\JsonResponse;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;


class DirectorController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Dashboard
    |--------------------------------------------------------------------------
    */

    public function index()
    {
        return view('director.index');
    }


    /*
    |--------------------------------------------------------------------------
    | Perfil
    |--------------------------------------------------------------------------
    */


    /*
    |--------------------------------------------------------------------------
    | Funcionários
    |--------------------------------------------------------------------------
    */

    /**
     * Lista de Funcionários
     */
    public function employees(){

        return view('pages.employee.index');

    }

    /**
     * Cadastro de Funcionários
     */
    public function formEmployee(){

        return view('pages.employee.register');

    }

    public function registerEmployee(Request $request)
    {
        return app(EmployeeController::class)->store($request);
    }

    public function showEmployee(User $employee)
    {
        $employee->load([
            'teacherSheet',
            'coordinatorSheet',
            'directorSheet',
        ]);

        return view('pages.employee.show', [
            'employee' => $employee,
        ]);
    }


    /*
    |--------------------------------------------------------------------------
    | Fórum
    |--------------------------------------------------------------------------
    */

    public function forum()
    {
        return view('pages.forum.index');
    }


    /*
    |--------------------------------------------------------------------------
    | Chat
    |--------------------------------------------------------------------------
    */

    public function chat()
    {
        return view('pages.chat.index');
    }

}
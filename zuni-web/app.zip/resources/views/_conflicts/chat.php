<x-panel.coordinator>
    <div class="col-span-4 row-span-4">Em desenvolvimento</div>
</x-panel.coordinator>
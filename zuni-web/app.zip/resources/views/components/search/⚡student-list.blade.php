<?php

use Illuminate\Support\Facades\Auth;
use App\Models\StudentSheet;
use App\Models\User;
use App\Models\Classroom;
use App\Enums\UserRole;
use GuzzleHttp\Psr7\Query;
use Livewire\Attributes\Computed;
use Livewire\Component;
use Livewire\WithPagination;
use Illuminate\Support\Facades\Gate;
use App\Models\Report;

new class extends Component
{
    use WithPagination;

    public string $name = '';
    public string $status = '';
    public string $class = '';

    /** IDs de StudentSheet marcados para criação de relatório. */
    public array $selected = [];

    public function updated(string $property): void
    {
        if (in_array($property, ['name', 'status', 'class'], true)) {
            $this->resetPage();
        }
    }

    /** Marca todos os alunos exibidos na página atual (já respeitando os filtros). */
    public function selectAllOnPage(): void
    {
        $this->selected = $this->students->pluck('id')->map(fn ($id) => (string) $id)->all();
    }

    public function clearSelection(): void
    {
        $this->selected = [];
    }

    /**
     * Encaminha os alunos marcados ao formulário de criação de Report.
     * O destino revalida existência e autorização de cada ID.
     */
    public function createReport()
    {
        abort_unless(Gate::allows('create', Report::class), 403);

        $ids = collect($this->selected)
            ->filter(fn ($id) => is_scalar($id) && ctype_digit((string) $id))
            ->map(fn ($id) => (int) $id)
            ->unique()
            ->values()
            ->all();

        if ($ids === []) {
            $this->addError('selected', 'Selecione ao menos um aluno.');

            return;
        }

        return $this->redirect(
            route(Auth::user()->role->value . '.report.create', ['students' => $ids])
        );
    }

    /**
     * Verifica se o usuário pode pesquisar todos os alunos.
     */
    public function canSearchAllStudents(): bool
    {
        return in_array(Auth::user()->role, [
            UserRole::COORDINATOR,
            UserRole::DIRECTOR,
        ]);
    }

    #[Computed]
    public function classrooms()
    {
        return Classroom::select('id', 'name')->get();
    }

    #[Computed]
    public function students()
    {
        $query = StudentSheet::query()
            ->with(['user', 'classroom']);

        /*
         * COORDINATOR e DIRECTOR
         * podem visualizar e pesquisar todos os alunos.
         */
        if ($this->canSearchAllStudents()) {

            // Filtro por nome do aluno
            $query->when($this->name, function ($query) {
                $query->whereHas('user', function ($query) {
                    $query->where(
                        'name',
                        'like',
                        '%' . $this->name . '%'
                    );
                });
            });

            // Filtro por status do usuário
            $query->when($this->status, function ($query) {
                $query->whereHas('user', function ($query) {
                    $query->where(
                        'status',
                        $this->status
                    );
                });
            });

            // Filtro por turma
            $query->when($this->class === 'null', function ($query) {
                $query->whereNull('classroom_id');
            });

            $query->when(
                $this->class && $this->class !== 'null',
                function ($query) {
                    $query->where('classroom_id', $this->class);
                }
            );

            // Filtro de ordem alfabética
            $query->when(
                $this->class === '' || $this->class === 'null',
                function ($query) {
                    $query->orderByDesc('student_sheets.id');
                },
                function ($query) {
                    $query->orderBy(
                        User::select('name')
                            ->whereColumn(
                                'users.id',
                                'student_sheets.student_id'
                            ),
                        'asc'
                    );
                }
            );
            $query;

        } elseif (Auth::user()->isTeacher()) {

            /*
             * Professor: alunos das turmas pelas quais é responsável.
             */
            $query->whereIn(
                'classroom_id',
                Auth::user()->classrooms()->pluck('classrooms.id')->all()
            )->orderByDesc('id');

        } else {

            /*
             * Usuários comuns:
             * somente alunos vinculados a eles como responsáveis.
             */
            $query->where(
                'guardian_id',
                Auth::id()
            )->orderByDesc('id');
        }

        return $query->paginate(32);
    }
};
?>

<div>

    

    {{-- FILTROS --}}
    @if ($this->canSearchAllStudents())

        <div class="
            card
            bg-base-100
            shadow-xl
            p-4
            sm:p-5
            md:p-6
            mb-6
        ">

            <h2 class="
                card-title
                mb-4
                text-base
                sm:text-lg
                md:text-xl
            ">
                Filtros
            </h2>

            <div class="
                grid
                grid-cols-1
                sm:grid-cols-2
                lg:grid-cols-3
                gap-3
                sm:gap-4
            ">

                {{-- Nome --}}
                <div class="form-control">

                    <label class="label">
                        <span class="label-text">
                            Aluno
                        </span>
                    </label>

                    <input
                        type="text"
                        wire:model.live.debounce.300ms="name"
                        placeholder="Nome do aluno"
                        class="input input-bordered w-full"
                    >

                </div>

                {{-- Status --}}
                <div class="form-control">

                    <label class="label">
                        <span class="label-text">
                            Status
                        </span>
                    </label>

                    <select
                        wire:model.live="status"
                        class="select select-bordered w-full"
                    >
                        <option value="">Todos</option>
                        <option value="pending">Pendente</option>
                        <option value="active">Ativo</option>
                        <option value="inactive">Inativo</option>
                        <option value="suspended">Suspenso</option>
                    </select>

                </div>

                {{-- Turma --}}
                <div class="form-control">

                    <label class="label">
                        <span class="label-text">
                            Turma
                        </span>
                    </label>

                    <select
                        wire:model.live="class"
                        class="select select-bordered w-full"
                    >
                        <option value="">Todas</option>
                        <option value="null">Nenhuma</option>

                        @foreach ($this->classrooms as $classroom)
                            <option value="{{ $classroom->id }}">
                                {{ $classroom->name }}
                            </option>
                        @endforeach
                    </select>

                </div>

            </div>

        </div>

    @endif

    @if (auth()->user()->isGuardian())

        <div class="flex justify-end mb-6">

            <a
                href="{{ route('guardian.student.register') }}"
                class="btn bg-Csecondary text-white"
            >
                + Adicionar criança
            </a>

        </div>

    @endif



    {{-- RESULTADOS RESPONSÁVEL --}}
    <div class="flex flex-col gap-4">

    @if (auth()->user()->isGuardian())
        @forelse ($this->students as $student)

            <div
                wire:key="student-{{ $student->id }}"
                class="card bg-base-100"
            >
                <a href="{{ route('guardian.student.show', $student->user->id) }}"
                        >
                    <div
                        class="
                            card-body
                            flex
                            flex-col
                            md:flex-row
                            items-center
                            justify-between
                            gap-6
                            rounded-xl
                            shadow-[0_0_20px_rgba(0,0,0,0.15)]
                            p-5
                            sm:p-6
                            transition
                            
                            hover:shadow-[0_0_20px_rgba(0,0,0,0.4)]
                            

                        "
                    >
    
                        {{-- LADO ESQUERDO --}}
                        <div class="flex items-center gap-5 w-full">
    
                            {{-- Avatar --}}
                            <div class="avatar shrink-0">
    
                                <div class="w-16 sm:w-20 rounded-full">
    
                                    <img
                                        src="https://ui-avatars.com/api/?name={{ urlencode($student->user->name) }}&background=random"
                                        alt="Avatar de {{ $student->user->name }}"
                                    />
    
                                </div>
    
                            </div>
    
    
                            {{-- INFORMAÇÕES --}}
                            <div class="min-w-0 px-4">
    
                                <h2 class="
                                    text-xl
                                    sm:text-2xl
                                    font-bold
                                    truncate
                                ">
                                    {{ $student->user->name ?? 'Nome da criança' }}
                                </h2>
    
    
                                <p class="text-sm sm:text-base text-base-content/60">
    
                                    {{ $student->classroom->name ?? 'Turma não definida' }}
    
                                    @if (!empty($student->classroom->shift))
                                        • {{ $student->classroom->shift }}
                                    @endif
    
                                </p>
    
    
                                {{-- INFORMAÇÕES RÁPIDAS --}}
                                <div class="
                                    flex
                                    flex-wrap
                                    gap-2
                                    mt-2
                                ">
    
                                    <span class="badge text-white bg-Csecondary">
                                        Matrícula: {{ $student->student_id }}
                                    </span>
    
                                    <span class="badge text-white bg-Csecondary">
                                        {{ $student->age ?? '0' }} anos
                                    </span>
    
                                </div>
    
                            </div>
    
                        </div>
    
    
                        {{-- LADO DIREITO --}}
                        <div class="
                            text-right
                            md:text-right
                            w-fit
                            md:w-auto
                            shrink-0
                        ">
    
                            <p class="text-sm text-base-content/60">
                                Situação
                            </p>
    
    
                            <p
                                @class([
                                    'text-lg font-semibold',
    
                                    'text-green-600' =>
                                        $student->user?->status?->value === 'active',
    
                                    'text-red-600' =>
                                        $student->user?->status?->value === 'inactive',
    
                                    'text-amber-500' =>
                                        !in_array(
                                            $student->user?->status?->value,
                                            ['active', 'inactive']
                                        ),
                                ])
                            >
                                {{ $student->user?->status?->label() ?? 'Não encontrado' }}
                            </p>
    
    
                            {{-- FREQUÊNCIA --}}
                            <div class="mt-2">
    
                                <span class="badge text-white bg-Csecondary">
                                    Frequência:
                                    {{ $student->attendance ?? 'Sem frequência' }}
                                </span>
    
                            </div>
    
                        </div>
    
                    </div>
                </a>

            </div>

        @empty

            <div class="text-center py-10">

                <p class="text-base-content/60">
                    Nenhum aluno encontrado.
                </p>

            </div>

        @endforelse

    @else 

        @can('create', \App\Models\Report::class)
            <div class="flex flex-wrap items-center justify-between gap-3 mb-4">
                <p class="text-sm text-base-content/60">
                    Marque um ou mais alunos para criar um relatório.
                    @error('selected') <span class="text-error">{{ $message }}</span> @enderror
                </p>

                <div class="flex flex-wrap gap-2">
                    <button type="button" wire:click="selectAllOnPage" class="btn btn-sm btn-outline">
                        Selecionar todos desta página
                    </button>
                    <button type="button" wire:click="clearSelection" class="btn btn-sm btn-ghost">
                        Limpar seleção
                    </button>
                    <button
                        type="button"
                        wire:click="createReport"
                        class="btn btn-sm bg-Csecondary text-white"
                    >
                        Criar relatório ({{ count($selected) }})
                    </button>
                </div>
            </div>
        @endcan

        {{-- RESULTADOS --}} 
        <div
            class=" grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5 lg:gap-6 "> 
            @forelse ($this->students as $student) 
                <div 
                wire:key="student-{{ $student->id }}"
                class=" card bg-base-100 border border-base-200 shadow-sm transition-shadow hover:shadow-md h-fit "
                >
                    <div class="card-body p-4 sm:p-5 md:p-6">
                        <div class="flex items-center gap-3">
                            @can('create', \App\Models\Report::class)
                                <input
                                    type="checkbox"
                                    wire:model.live="selected"
                                    value="{{ $student->id }}"
                                    class="checkbox checkbox-primary"
                                    aria-label="Selecionar {{ $student->user->name }} para relatório"
                                >
                            @endcan
                            <h2 class="card-title text-base sm:text-lg"> {{ $student->user->name }} </h2>
                        </div>
                        <p class="text-xs sm:text-sm text-base-content/60"> Student #{{ $student->student_id }} </p>
                        <div class="divider my-2"></div>
                        <div class="flex justify-between gap-3">
                            <span class="text-sm text-base-content/60"> Student ID </span>
                            <span class="font-medium"> {{ $student->student_id }} </span> 
                        </div>
                        <div class="flex justify-between gap-3">
                            <span class="text-sm text-base-content/60"> Status </span>
                            <span class="font-medium"> {{ $student->user->status->value }} </span>
                        </div>
                        <div class="card-actions justify-end mt-4"> 
                            <a
                            @switch(auth()->user()->role->value)
                                @case('teacher')    href="{{ route('teacher.student.show', $student->user) }}"     @break 
                                @case('coordinator')    href="{{ route('coordinator.student.show', $student->user) }}"     @break 
                            @endswitch
                            class=" btn btn-sm sm:btn-md text-white bg-Cprimary w-full sm:w-auto "
                            > 
                                Mais informações 
                                <span aria-hidden="true"> → </span> 
                            </a> 
                        </div>
                    </div>
                </div> 
            @empty 
            <div class="col-span-full text-center py-10">
                <p class="text-base-content/60"> Nenhum aluno encontrado. </p>
            </div> 
            @endforelse 
        </div>
        {{ $this->students->links() }}
    
    @endif
    </div>

</div>
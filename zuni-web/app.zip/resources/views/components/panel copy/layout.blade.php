<!DOCTYPE html>
<html lang="en" data-theme="lofi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ isset($title) ? $title . ' - Zuni' : 'Zuni'}}</title>
    <link rel="preconnect" href="<https://fonts.bunny.net>">
    <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600,700" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/daisyui@5" rel="stylesheet" type="text/css" />
    <link href="https://cdn.jsdelivr.net/npm/daisyui@5/themes.css" rel="stylesheet" type="text/css" />
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body class="min-h-screen flex flex-col bg-white font-sans text-Cprimary">

    <div class="drawer lg:drawer-open">
        <input id="sidebar-drawer" type="checkbox" class="drawer-toggle" />
        
        <div class="drawer-content flex flex-col min-h-screen">

            {{-- Messages --}}
            <span class="fixed left-1/2 -translate-x-1/2 top-[2vmin] z-10 w-[50%]">
                @foreach (['success', 'error', 'warning', 'info'] as $type)
                    @session($type)
                        <div
                            x-data="{ show: false }"
                            x-cloak
                            x-show="show"
                            x-transition:enter="transition ease-out duration-500"
                            x-transition:enter-start="opacity-0 -translate-y-20 scale-95"
                            x-transition:enter-end="opacity-100 translate-y-0 scale-100"
                            x-transition:leave="transition ease-in duration-500"
                            x-transition:leave-start="opacity-100 translate-y-0 scale-100"
                            x-transition:leave-end="opacity-0 -translate-y-20 scale-95"
                            x-init="
                                setTimeout(() => show = true, 100);
                                setTimeout(() => show = false, 5100);
                            "
                            class="alert alert-{{ $type }} mb-4"
                        >
                            <span>{{ $value }}</span>
                            <button
                                type="button"
                                @click="show = false"
                                class="btn btn-white btn-sm btn-circle ml-auto"
                                aria-label="Fechar"
                            >
                                ✕
                            </button>
                        </div>
                    @endsession
                @endforeach
            </span>

            {{-- Header --}}
            <header class="bg-base-100 border-b px-4 py-3 pt-12 sm:px-6 sm:p-12 flex items-center justify-between gap-4">

                {{-- Menu Mobile --}}
                <label for="sidebar-drawer" class="btn btn-ghost btn-circle lg:hidden shrink-0">
                        <img src="{{ asset('images/icons/gear.svg') }}" class="w-5 h-5" alt="Menu" />
                </label>

                {{-- Título --}}
                <div class="min-w-0 flex-1">
                    <h1 class="text-lg font-bold uppercase tracking-tight sm:text-xl md:text-2xl">
                        {!! $panelTitle ?? 'Painel' !!}
                    </h1>

                    <p class="mt-0.5 truncate text-xs text-base-content/50 sm:text-sm">
                        {!! $panelMessage ?? 'Bem-vindo ao seu painel de controle.' !!}
                    </p>
                </div>

                {{-- Ações --}}
                <div class="flex items-center gap-2 sm:gap-3 shrink-0">

                    {{-- Notificações --}}
                    <button
                        onclick="toggleNotifications()"
                        class="btn btn-ghost btn-circle btn-sm sm:btn-md"
                        aria-label="Notificações"
                    >
                        <div class="indicator">
                            <span class="indicator-item badge badge-error badge-xs sm:badge-sm">
                                3
                            </span>

                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke-width="1.5"
                                stroke="#FFAE00"
                                class="size-5 sm:size-6"
                            >
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.05c0 .243 0 .486-.002.729A8.967 8.967 0 013.69 15.77a23.848 23.848 0 005.454 1.31m5.713 0a24.255 24.255 0 01-5.713 0m5.713 0a3 3 0 11-5.713 0"
                                />
                            </svg>
                        </div>
                    </button>

                                        @php
                    $currentUser = auth()->user();

                    $roleLabel = match ($currentUser?->role?->value ?? $currentUser?->role) {
                        'admin' => 'Administrador',
                        'director' => 'Diretor',
                        'coordinator' => 'Coordenador',
                        'teacher' => 'Professor',
                        'student' => 'Aluno',
                        'guardian' => 'Responsável',
                        'staff' => 'Funcionário',
                        default => 'Usuário',
                    };

                    @endphp

                    {{-- Perfil --}}

                    <div class="dropdown dropdown-end hidden sm:block">

                        {{-- Trigger --}}
                        <div
                            tabindex="0"
                            role="button"
                            class="flex cursor-pointer items-center gap-2 rounded-xl bg-base-100 p-1.5 transition hover:bg-base-200 md:p-2"
                        >

                            {{-- Avatar --}}
                            <div class="avatar placeholder shrink-0">

                                <div class="w-9 rounded-full md:w-10">
                                    <img
                                        src="https://ui-avatars.com/api/?name={{ urlencode($currentUser?->name ?? 'Sem nome') }}"
                                        alt="Avatar de {{ $currentUser?->name ?? 'usuário' }}"
                                        class="object-cover"
                                    />
                                </div>

                            </div>


                            {{-- Informações --}}
                            <div class="hidden min-w-0 md:block">

                                <div class="flex max-w-40 items-center gap-1.5">

                                    <p class="truncate text-sm font-semibold">
                                        {{ $currentUser?->name ?? 'Sem nome' }}
                                    </p>

                                    <img
                                        src="{{ asset('images/icons/chevronDown.svg') }}"
                                        class="h-3 w-3 shrink-0 opacity-60"
                                        alt=""
                                    >

                                </div>

                                <p class="mt-0.5 max-w-40 truncate text-[10px] text-Ctext-muted">
                                    {{ $roleLabel }}
                                </p>

                            </div>

                        </div>


                        {{-- Dropdown --}}
                        <ul
                            tabindex="0"
                            class="dropdown-content menu z-50 mt-2 w-64 rounded-2xl border border-base-200 bg-base-100 p-2 shadow-xl"
                        >

                            {{-- Cabeçalho do dropdown --}}
                            <li class="mb-1 pointer-events-none">

                                <div class="flex items-center gap-3 rounded-xl px-3 py-2">

                                    <div class="avatar placeholder shrink-0">

                                        <div class="w-10 rounded-full">
                                            <img
                                                src="https://ui-avatars.com/api/?name={{ urlencode($currentUser?->name ?? 'Sem nome') }}"
                                                alt=""
                                            >
                                        </div>

                                    </div>

                                    <div class="min-w-0">

                                        <p class="truncate text-sm font-semibold">
                                            {{ $currentUser?->name ?? 'Sem nome' }}
                                        </p>

                                        <p class="truncate text-xs text-Ctext-muted">
                                            {{ $currentUser?->email ?? 'Sem e-mail' }}
                                        </p>

                                    </div>

                                </div>

                            </li>

                            <div class="divider my-1"></div>


                            {{-- Perfil --}}
                            <li>

                                <a
                                    href="{{ route(($currentUser?->role?->value ?? $currentUser?->role) . '.profile') }}"
                                    class="gap-3 rounded-xl"
                                >

                                    <svg
                                        xmlns="http://www.w3.org/2000/svg"
                                        class="h-4 w-4"
                                        fill="none"
                                        viewBox="0 0 24 24"
                                        stroke="currentColor"
                                    >
                                        <path
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                            stroke-width="1.8"
                                            d="M15.75 6.75a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.5 20.25a7.5 7.5 0 0 1 15 0"
                                        />
                                    </svg>

                                    <span>
                                        Meu perfil
                                    </span>

                                </a>

                            </li>


                            {{-- Sair --}}
                            <li>

                                <form action="{{ route('logout') }}" method="POST">
                                    @csrf

                                    <button
                                        type="submit"
                                        class="flex items-center gap-2 bg-transparent border-0 p-0 text-Csecondary cursor-pointer"
                                    >
                                        <x-svg.icon.logout class="text-Csecondary" />
                                        Sair
                                    </button>
                                </form>

                            </li>

                        </ul>

                    </div>

                </div>
            </header>

            {{-- Main Content --}}


            <main class="flex-1 bg-base-200 p-4 md:p-6 overflow-auto">    
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 lg:grid-rows-4 gap-4">
                    @isset($slot)
                        {!! $slot !!}
                    @else
                        <div>Sem Dashboard</div>
                    @endisset
                </div>
            </main>
        </div>

        {{-- Sidebar (Drawer) --}}
        <div class="drawer-side panel-drawer-side">
            <label for="sidebar-drawer" class="drawer-overlay"></label>
            
            <aside class="bg-Csecondary text-primary-content flex h-screen min-h-0 flex-col sm:pt-5 {{ request()->routeIs('coordinator.*') ? 'coordinator-sidebar w-72 max-w-[85vw] lg:w-64' : '' }}">

                {{-- Botão de fechar --}}

                {{-- Logo --}}
                <div class="flex justify-center mt-2 md:mt-8 mb-2 md:mb-8 w-full h-8">
                    <a href="/">
                        <x-svg.logo.mark class="size-8 text-white hover:text-Cprimary transition" />
                    </a>
                </div>

                {{-- Navegação --}}
                <div class="panel-sidebar-nav min-h-0 flex-1 px-3 overflow-y-auto sm:pt-7">
                    <ul class="menu w-full gap-0 md:gap-[2.5vmin] text-sm md:text-[1vmax] [&>li>a]:py-1.5 md:[&>li>a]:py-2">
                        @isset($aside)
                            {!! $aside  !!}
                        @else
                            <div>Sem Aside</div>
                        @endisset
                    </ul>
                </div>

                {{-- Rodapé --}}
                <div class="border-t border-primary-content/20 p-1 md:p-3">
                    <ul class="menu w-full text-sm md:text-base [&>li>a]:py-1 md:[&>li>a]:py-2">
                        <li>
                            <a href="#">
                                <x-svg.icon.config class="text-white" />
                                Configurações
                            </a>
                        </li>

                        <li>
                            <form action="{{ route('logout') }}" method="POST">
                                @csrf

                                <button
                                    type="submit"
                                    class="flex items-center gap-2 bg-transparent border-0 p-0 text-white cursor-pointer"
                                >
                                    <x-svg.icon.logout class="text-white" />
                                    Encerrar sessão
                                </button>
                            </form>
                        </li>
                    </ul>
                </div>

            </aside>
        </div>

    </div>

    <script src="https://kit.fontawesome.com/c0becc67c4.js" crossorigin="anonymous"></script>
</body>

</html>
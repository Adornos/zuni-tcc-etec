<x-dynamic-component :component="'panel.' . auth()->user()->role->value">

    @php
        $canAddStudents = Auth::user()->isCoordinator();
        $canCreateReports = Gate::allows('create', \App\Models\Report::class);
        $reportPrefix = Auth::user()->role->value;
    @endphp

    <div class="col-span-4 row-span-4">
        <div class="card bg-base-100 shadow-xl">
            <div class="card-body">

                <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-6">
                    <div>
                        <h2 class="text-2xl font-bold">
                            Alunos da turma
                        </h2>

                        <p class="text-base-content/60">
                            {{ $classroom->name }}
                        </p>
                    </div>

                    <div class="badge badge-primary badge-lg">
                        {{ $classroom->students->count() }} alunos
                    </div>
                </div>

                {{-- Seleção de alunos para criar relatório (GET). Os checkboxes ligam-se a este form pelo atributo form="report-select". --}}
                @if ($canCreateReports)
                    <form
                        id="report-select"
                        method="GET"
                        action="{{ route($reportPrefix . '.report.create') }}"
                        class="flex flex-wrap items-center justify-end gap-2 mb-4"
                    >
                        <button type="button" class="btn btn-sm btn-outline"
                                onclick="document.querySelectorAll('input[form=report-select][name=\'students[]\']').forEach(i => i.checked = true)">
                            Selecionar todos
                        </button>
                        <button type="button" class="btn btn-sm btn-ghost"
                                onclick="document.querySelectorAll('input[form=report-select][name=\'students[]\']').forEach(i => i.checked = false)">
                            Limpar seleção
                        </button>
                        <button type="submit" class="btn btn-sm bg-Csecondary text-white">
                            Criar relatório para os selecionados
                        </button>
                    </form>
                @endif

                <form
                    action="{{ route('coordinator.classroom.students.update', $classroom) }}"
                    method="POST"
                >
                    @csrf
                    @method('PUT')

                    <div class="space-y-6">

                        {{-- ALUNOS JÁ ASSOCIADOS À TURMA --}}
                        <div>
                            <div class="flex items-center gap-2 mb-3">
                                <h3 class="text-lg font-semibold">
                                    Alunos da turma
                                </h3>

                                <span class="badge badge-success">
                                    {{ $classroom->students->count() }}
                                </span>
                            </div>
                        @if($canAddStudents)
                            <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">

                                @forelse ($classroom->students as $studentSheet)

                                    <label
                                        class="flex items-center gap-3 p-4 rounded-box
                                               border border-base-300
                                               hover:bg-base-200
                                               hover:shadow-lg
                                               cursor-pointer transition"
                                    >
                                        <input
                                            type="checkbox"
                                            name="students[]"
                                            value="{{ $studentSheet->user->id }}"
                                            class="checkbox checkbox-primary"
                                            checked
                                        >
                                        <div class="flex-1 min-w-0">

                                            <p class="font-semibold truncate">
                                                {{ $studentSheet->user->name }}
                                            </p>

                                            <p class="text-sm text-base-content/60">
                                                Matrícula:
                                                {{ $studentSheet->registration_number ?? '—' }}
                                            </p>

                                        </div>

                                        @if ($canCreateReports)
                                            <input
                                                type="checkbox"
                                                form="report-select"
                                                name="students[]"
                                                value="{{ $studentSheet->id }}"
                                                class="checkbox checkbox-sm"
                                                title="Selecionar para relatório"
                                                aria-label="Selecionar {{ $studentSheet->user->name }} para relatório"
                                                onclick="event.stopPropagation()"
                                            >
                                        @endif

                                    </label>

                                @empty

                                    <div class="col-span-full">
                                        <div class="alert">
                                            <span>
                                                Nenhum aluno está associado a esta turma.
                                            </span>
                                        </div>
                                    </div>

                                @endforelse

                            </div>
                        </div>                      

                        {{-- ALUNOS SEM TURMA --}}
                        <div>

                            <div class="flex items-center gap-2 mb-3">
                                <h3 class="text-lg font-semibold">
                                    Alunos disponíveis
                                </h3>

                                <span class="badge badge-warning">
                                    {{ $availableStudents->count() }}
                                </span>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">

                                @forelse ($availableStudents as $studentSheet)

                                    <label
                                        class="flex items-center gap-3 p-4 rounded-box
                                               border border-base-300
                                               hover:bg-base-200
                                               cursor-pointer transition"
                                    >

                                        <input
                                            type="checkbox"
                                            name="students[]"
                                            value="{{ $studentSheet->user->id }}"
                                            class="checkbox checkbox-primary"
                                        >

                                        <div class="flex-1 min-w-0">

                                            <p class="font-semibold truncate">
                                                {{ $studentSheet->user->name }}
                                            </p>

                                            <p class="text-sm text-base-content/60">
                                                Matrícula:
                                                {{ $studentSheet->registration_number ?? '—' }}
                                            </p>

                                        </div>

                                    </label>

                                @empty

                                    <div class="col-span-full">
                                        <div class="alert alert-success">
                                            <span>
                                                Não há alunos sem turma no momento.
                                            </span>
                                        </div>
                                    </div>

                                @endforelse

                            </div>
                        </div>


                        {{-- BOTÃO --}}
                        <div class="flex justify-end pt-4 border-t border-base-300">

                            <button
                                type="submit"
                                class="btn btn-primary"
                            >
                                Salvar alunos
                            </button>

                        </div>
                        @else
                            @forelse ($classroom->students as $studentSheet)
                                <div class="flex items-center gap-3 rounded-box border border-base-300 hover:bg-base-200 hover:shadow-lg transition pl-4">
                                    @if ($canCreateReports)
                                        <input
                                            type="checkbox"
                                            form="report-select"
                                            name="students[]"
                                            value="{{ $studentSheet->id }}"
                                            class="checkbox checkbox-primary"
                                            aria-label="Selecionar {{ $studentSheet->user->name }} para relatório"
                                        >
                                    @endif
                                    <a
                                        href="{{ route('teacher.student.show', ['student' => $studentSheet->user->id]) }}"
                                        class="flex flex-1 items-center gap-3 p-4 cursor-pointer"
                                    >
                                    <div class="flex-1 min-w-0">

                                        <p class="font-semibold truncate">
                                            {{ $studentSheet->user->name }}
                                        </p>

                                        <p class="text-sm text-base-content/60">
                                            Matrícula:
                                            {{ $studentSheet->registration_number ?? '—' }}
                                        </p>

                                    </div>
                                    </a>
                                </div>

                            @empty

                                <div class="col-span-full">
                                    <div class="alert">
                                        <span>
                                            Nenhum aluno está associado a esta turma.
                                        </span>
                                    </div>
                                </div>

                            @endforelse
                        @endif
                    </div>
                </form>

            </div>
        </div>
    </div>

</x-dynamic-component>

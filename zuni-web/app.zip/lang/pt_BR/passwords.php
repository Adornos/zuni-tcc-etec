<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Password Reset Language Lines
    |--------------------------------------------------------------------------
    */

    'reset' => 'Sua senha foi redefinida.',
    'sent' => 'Enviamos o link para redefinição da sua senha por e-mail.',
    'throttled' => 'Aguarde antes de tentar novamente.',
    'token' => 'Este token de redefinição de senha é inválido.',
    'user' => 'Não encontramos um usuário com esse endereço de e-mail.',

];